# Developer Onboarding Guide
## Building Your First Plugin for the ARIA + ACES Platform

**Audience:** Software engineers new to the platform  
**Time to first plugin:** ~2 hours  
**Prerequisites:** Java or any REST-capable language, access to internal platform registry

---

## Before You Start: The Three Things You Must Understand

**1. Every capability is a plugin.**  
There are no special cases. There are no "core" capabilities that bypass the plugin system. The built-in capabilities ship as internal plugins. Your plugin works the same way.

**2. Your plugin lives in exactly one layer.**  
Before writing a single line of code, answer: which layer does my capability belong to? Interaction, Governance, Execution, or Integration. If you're unsure, consult the type registry. If your capability spans two layers — it doesn't. Split it.

**3. ARIA discovers your plugin automatically.**  
Once registered, ARIA picks up your plugin within 60 seconds. You do not configure ARIA. You do not update any config file. You register your manifest and ARIA does the rest.

---

## Step 0: Choose Your Layer and Type

Answer these questions in order. Stop at the first "yes."

```
Does your capability receive requests from humans or external systems?
  YES → Interaction Layer
  
Does your capability evaluate risk, apply policies, track cost, or
process production outcomes?
  YES → Governance Layer

Does your capability execute work — run an AI agent, invoke a tool,
orchestrate a workflow?
  YES → Execution Layer

Does your capability connect the platform to an external system —
a scanner, observability platform, CI/CD tool, ticketing system?
  YES → Integration Layer
```

Once you have your layer, find your type in the type registry:

| If you're building... | Layer | Type |
|----------------------|-------|------|
| A new AI agent (Copilot, Claude, custom) | execution | agent |
| A new MCP server | execution | mcp-server |
| A reusable tool (formatter, test runner) | execution | tool |
| A multi-step workflow template | execution | workflow |
| A new security/quality scanner | integration | scanner |
| A new incident/alert source | integration | observability |
| A new CI/CD connector | integration | ci-cd |
| A new ticketing system | integration | ticketing |
| A risk/domain policy | governance | policy |
| A post-deploy feedback source | governance | feedback |
| A cost tracking integration | governance | cost-meter |
| A new UI dashboard | interaction | ui |
| A new notification channel | interaction | notification |
| A new API surface | interaction | api |

---

## Step 1: Write Your Plugin Manifest

Create a file called `plugin.json` in your project root. This is your registration payload.

### Minimal valid manifest:

```json
{
  "pluginId": "your-plugin-id",
  "displayName": "Your Plugin Name",
  "version": "1.0.0",
  "layer": "execution",
  "type": "agent",
  "vendor": "internal",
  "owningTeam": "your-team-name",
  "status": "experimental",
  "capabilities": ["code-generation"],
  "trustable": true,
  "costModel": {
    "unit": "token",
    "rate": 0.00002,
    "budget": 200.00
  },
  "healthCheck": {
    "endpoint": "https://your-service.internal/health",
    "intervalSeconds": 60,
    "timeoutSeconds": 5
  },
  "metadata": {
    "description": "One paragraph describing what this plugin does.",
    "tags": ["your-tag", "another-tag"]
  }
}
```

### Naming your pluginId

Follow this convention: `{layer-hint}-{vendor-or-team}-{capability}-v{major}`

Good examples:
- `agent-internal-java-refactor-v1`
- `mcp-confluence-search-v1`
- `scanner-internal-secrets-v1`
- `feedback-splunk-incidents-v1`

Bad examples:
- `my-plugin` (no layer hint, no version)
- `JavaRefactorAgent` (PascalCase — must be kebab-case)
- `agent-v1` (no capability description)

### Manifest validation checklist

Before moving to Step 2, verify:

- [ ] `pluginId` is kebab-case, globally unique, includes layer hint and version
- [ ] `layer` is exactly one of: `interaction | governance | execution | integration`
- [ ] `type` is in the type registry for your chosen layer
- [ ] `capabilities` only contains tokens from the capability token registry
- [ ] `trustable` is `true` only if `layer = execution` and `type = agent`
- [ ] `costModel.rate` is set (use 0 if no cost, with `unit: "none"`)
- [ ] `healthCheck.endpoint` is reachable from the platform network

---

## Step 2: Implement the Plugin Interface

Each plugin type has a standard interface you must implement. The interface is defined in TypeScript but your implementation can be in any language — you just need to expose the correct HTTP endpoints.

### 2A. Agent Plugin (execution/agent)

Your agent must expose three HTTP endpoints:

#### GET /health
```json
// Response 200
{
  "status": "healthy",
  "latencyMs": 45
}
```

#### GET /manifest
```json
// Response 200 — return your plugin.json contents
{ ...your plugin manifest... }
```

#### POST /execute
```json
// Request body
{
  "executionId": "exec-uuid-here",
  "taskType": "code-generation",
  "context": {
    "repoName": "my-service",
    "branch": "feature/refactor-auth",
    "filesInScope": ["src/auth/AuthService.java"],
    "instructions": "Refactor to use constructor injection"
  },
  "constraints": {
    "maxTokens": 4000,
    "timeoutSeconds": 120,
    "environment": "dev"
  },
  "ariaContext": {
    "trustScore": 0.82,
    "activeConstraints": ["no-config-modification"]
  }
}

// Response 200
{
  "executionId": "exec-uuid-here",
  "status": "completed",
  "artifacts": [
    {
      "path": "src/auth/AuthService.java",
      "action": "modified",
      "changeDescription": "Replaced field injection with constructor injection"
    }
  ],
  "tokenCount": 1240,
  "durationMs": 3400,
  "agentReasoning": "Constructor injection was preferred because it makes dependencies explicit and testable. I did not modify the AuthConfig class as it was outside scope.",
  "confidence": 0.91
}
```

**Critical:** The `agentReasoning` field is mandatory. This is what feeds Decision Archaeology. If your agent cannot explain its reasoning, ARIA cannot explain the decision. Do not return an empty string.

#### Java Spring Boot example — agent skeleton:

```java
@RestController
@RequestMapping("/")
public class AgentPluginController {

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of(
            "status", "healthy",
            "latencyMs", measureLatency()
        ));
    }

    @GetMapping("/manifest")
    public ResponseEntity<String> manifest() throws IOException {
        String manifest = new ClassPathResource("plugin.json")
            .getContentAsString(StandardCharsets.UTF_8);
        return ResponseEntity.ok()
            .contentType(MediaType.APPLICATION_JSON)
            .body(manifest);
    }

    @PostMapping("/execute")
    public ResponseEntity<AgentResponse> execute(
            @RequestBody AgentRequest request) {
        
        // 1. Validate execution ID
        log.info("Executing task: {} for agent context trust: {}", 
            request.getExecutionId(), 
            request.getAriaContext().getTrustScore());

        // 2. Run your agent logic
        AgentResult result = yourAgentLogic.run(request);

        // 3. Return structured response — agentReasoning is MANDATORY
        return ResponseEntity.ok(AgentResponse.builder()
            .executionId(request.getExecutionId())
            .status("completed")
            .artifacts(result.getArtifacts())
            .tokenCount(result.getTokenCount())
            .durationMs(result.getDurationMs())
            .agentReasoning(result.getReasoning()) // Never null, never empty
            .confidence(result.getConfidence())
            .build());
    }
}
```

---

### 2B. MCP Server Plugin (execution/mcp-server)

MCP servers use the Model Context Protocol. You need two additional endpoints beyond health and manifest:

#### GET /tools
```json
// Response 200
{
  "tools": [
    {
      "name": "search-confluence",
      "description": "Search Confluence for pages matching a query",
      "inputSchema": {
        "type": "object",
        "properties": {
          "query": { "type": "string", "description": "Search query" },
          "spaceKey": { "type": "string", "description": "Confluence space key (optional)" }
        },
        "required": ["query"]
      }
    }
  ]
}
```

#### POST /tools/{toolName}
```json
// Request
{
  "params": {
    "query": "ARIA architecture",
    "spaceKey": "PLATFORM"
  }
}

// Response 200
{
  "result": {
    "pages": [
      { "title": "ARIA Architecture Overview", "url": "https://confluence.internal/...", "excerpt": "..." }
    ]
  },
  "durationMs": 280
}
```

---

### 2C. Scanner Plugin (integration/scanner)

Scanners expose a scan endpoint and optionally a webhook receiver:

#### POST /scan
```json
// Request
{
  "target": {
    "repoName": "payment-service",
    "branch": "feature/new-endpoint",
    "commitSha": "abc123",
    "filesChanged": ["src/payment/PaymentController.java"]
  }
}

// Response 200
{
  "scannerId": "scanner-internal-secrets-v1",
  "timestamp": "2025-01-15T14:32:00Z",
  "status": "medium",
  "findings": [
    {
      "severity": "medium",
      "rule": "HARDCODED_CREDENTIAL",
      "file": "src/payment/PaymentController.java",
      "line": 42,
      "description": "Potential hardcoded API key detected"
    }
  ]
}
```

---

### 2D. Policy Plugin (governance/policy)

Policies evaluate a change and return a verdict:

#### POST /evaluate
```json
// Request
{
  "agentId": "agent-copilot-v1",
  "filesChanged": ["src/auth/SecurityConfig.java"],
  "servicesInvolved": ["auth-service"],
  "environment": "prod",
  "toolResults": { "snyk": "MEDIUM", "sonar": "PASS", "raven": "PASS" },
  "agentTrustScore": 0.54
}

// Response 200
{
  "passed": false,
  "severity": "blocking",
  "violatedRules": ["AUTH_CONFIG_PROD_REQUIRES_HUMAN_REVIEW"],
  "reasoning": "Changes to authentication configuration in production require human review per Platform Policy v1.2. This applies regardless of tool scan results."
}
```

---

### 2E. Feedback Plugin (governance/feedback)

Feedback plugins subscribe to production events and push them to ARIA:

#### POST /subscribe
```json
// Request
{ "filter": { "services": ["payment-service", "auth-service"], "minSeverity": "medium" } }

// Response 200
{ "subscriptionId": "sub-uuid-here" }
```

#### Pushing events to ARIA (your plugin calls ARIA, not the reverse):
```
POST https://aria.internal/api/v1/feedback
Authorization: Bearer {your-plugin-jwt}
Content-Type: application/json

{
  "eventId": "pd-incident-42601",
  "timestamp": "2025-01-15T22:14:00Z",
  "type": "incident",
  "severity": "high",
  "affectedServices": ["auth-service"],
  "linkedPrIds": ["PR-4821"],
  "correlationConfidence": 0.87,
  "detail": "Auth service returned 401 storm after PR-4821 deploy. Rolled back at 22:18."
}
```

---

## Step 3: Register Your Plugin

Once your service is deployed and the health endpoint returns 200, register with the platform:

```bash
curl -X POST https://platform.internal/api/v1/platform/plugins \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}" \
  -H "Content-Type: application/json" \
  -d @plugin.json
```

Successful response:
```json
{
  "pluginId": "your-plugin-id",
  "registrationId": "REG-2025-001234",
  "status": "REGISTERED",
  "nextStep": "Health check running. Status updates to ACTIVE within 60 seconds.",
  "ariaTrustInitialized": true,
  "initialTrustScore": 0.30
}
```

### Possible errors and fixes:

| Error | Fix |
|-------|-----|
| `409 Conflict` | pluginId already registered. Change your pluginId. |
| `422 Unprocessable` | Schema validation failed. Check the error body for the failing field. |
| `503 Health Check Failed` | Your health endpoint didn't respond within timeoutSeconds. Check your deployment. |
| `400 Invalid type` | Your `type` isn't in the registry for your `layer`. Check the type registry. |
| `400 Invalid capability` | One of your `capabilities` tokens isn't registered. Check the capability token list. |

---

## Step 4: Verify Your Plugin Is Live

Check your plugin's status:

```bash
curl https://platform.internal/api/v1/platform/plugins/your-plugin-id \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}"
```

You should see `"status": "active"` within 60–90 seconds of registration.

If you registered an agent plugin, check your trust profile:

```bash
curl https://platform.internal/api/v1/aria/agents/your-plugin-id \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}"
```

Expected response:
```json
{
  "agentId": "your-plugin-id",
  "trustScore": 0.30,
  "status": "EXPERIMENTAL",
  "totalPRs": 0,
  "prodIncidents": 0,
  "trend": "new",
  "message": "Complete 10 clean deployments to be promoted to ACTIVE status."
}
```

---

## Step 5: Test Your Plugin End-to-End

Use the platform test harness to send a synthetic PR payload through ARIA and verify your plugin is being called:

```bash
curl -X POST https://platform.internal/api/v1/aria/decide \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "prId": "TEST-001",
    "filesChanged": ["src/utils/StringHelper.java"],
    "changeType": "MODIFY",
    "author": "AI_AGENT",
    "agentId": "your-plugin-id",
    "servicesInvolved": ["notification-service"],
    "toolResults": { "snyk": "PASS", "sonar": "PASS", "raven": "PASS" },
    "metadata": { "environment": "dev", "deploymentType": "microservice" }
  }'
```

A successful response will include your agent's trust profile in the decision:
```json
{
  "finalDecision": "REQUIRES_APPROVAL",
  "riskLevel": "MEDIUM",
  "agentTrustImpact": "New agent (your-plugin-id) with trust score 0.30. EXPERIMENTAL status applies — minimum decision is REQUIRES_APPROVAL until 10 clean deployments complete.",
  "confidenceScore": 0.78,
  ...
}
```

The `REQUIRES_APPROVAL` decision is expected for a new agent. It will automatically become `ALLOW` for low-risk changes once your trust score climbs above 0.55 after clean deployments.

---

## Step 6: Monitor Your Plugin

### Check decision history for your plugin:
```bash
curl "https://platform.internal/api/v1/aria/decisions?agentId=your-plugin-id&from=2025-01-01" \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}"
```

### Check trust score history:
```bash
curl "https://platform.internal/api/v1/aria/agents/your-plugin-id/trust-history" \
  -H "Authorization: Bearer ${PLATFORM_SERVICE_TOKEN}"
```

### View your plugin in the Platform Explorer:
Open `https://platform.internal/explorer` → Plugin Registry → search your plugin ID.

---

## Common Mistakes and How to Avoid Them

### Mistake 1: Empty or generic agentReasoning
**What happens:** ARIA's Decision Archaeology shows "No reasoning provided" — useless for engineers and compliance.  
**Fix:** Always return a specific, non-empty `agentReasoning` that explains what the agent changed and why it made those specific choices.

### Mistake 2: Using trustable: true for non-agent plugins
**What happens:** Registration fails with `422: trustable: true is only valid for execution/agent plugins`.  
**Fix:** Set `trustable: false` for all plugins except `execution/agent` types.

### Mistake 3: Declaring capabilities not in the registry
**What happens:** Registration fails with `400: Unregistered capability token: your-custom-token`.  
**Fix:** Use only the tokens in the capability registry. If you need a new token, request it from the platform team — it takes 1 business day.

### Mistake 4: Health endpoint returns non-200 intermittently
**What happens:** ARIA marks your plugin INACTIVE. All decisions that would route to it now go to fallback behavior.  
**Fix:** Make your health endpoint lightweight. It should not call your agent API — just check that your service is up and return 200 in < 1 second.

### Mistake 5: Hardcoding environment assumptions
**What happens:** Your plugin behaves differently in dev vs prod in ways ARIA doesn't know about.  
**Fix:** Always check `request.constraints.environment` and adjust behavior accordingly. ARIA passes the environment so you can act on it.

### Mistake 6: Not reading ariaContext
**What happens:** Your agent ignores trust constraints and performs actions that ARIA would block.  
**Fix:** Read `ariaContext.activeConstraints` on every execute call. If `no-config-modification` is in the constraints, do not modify config files regardless of instructions.

---

## Getting Help

**Slack:** `#platform-plugins` — for registration issues and interface questions  
**Platform team office hours:** Every Tuesday 2–3pm — bring your plugin manifest for review  
**Plugin registry dashboard:** `https://platform.internal/explorer`  
**Plugin contract spec:** See `PLUGIN_CONTRACT_SPEC.md` in the platform engineering repo  
**Full ADR:** See `ARIA_ADR.md` for architecture decisions and rationale  

---

## Appendix: Quick Reference Cards

### New Agent Plugin — Minimum Viable Checklist
```
□ plugin.json written and validated
□ GET /health returns { status, latencyMs }
□ GET /manifest returns plugin.json
□ POST /execute accepts AgentRequest, returns AgentResponse
□ agentReasoning field always populated (never null, never empty)
□ ariaContext read and respected in execution
□ trustable: true in manifest
□ Registered via POST /api/v1/platform/plugins
□ Status confirmed as ACTIVE
□ Test payload executed successfully
```

### New MCP Server — Minimum Viable Checklist
```
□ plugin.json written (trustable: false, type: mcp-server)
□ GET /health returns { status, latencyMs }
□ GET /tools returns list of available tools with input schemas
□ POST /tools/{toolName} accepts params, returns structured result
□ All tool invocations logged (platform does this automatically)
□ Registered and ACTIVE
```

### New Scanner Plugin — Minimum Viable Checklist
```
□ plugin.json written (layer: integration, type: scanner)
□ GET /health returns { status }
□ POST /scan accepts ScanTarget, returns ScanResult
□ status field uses: pass | low | medium | high | critical
□ findings array always present (empty array if no findings)
□ Registered and ACTIVE
□ Verify ARIA includes your scanner signal in test decision
```

---

*Questions? The plugin contract is the truth. This guide is the path to following it.*
