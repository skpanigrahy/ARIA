# Plugin Contract Specification
## ARIA + ACES Modular Platform
**Version:** 1.0  
**Status:** Draft — Phase 1 Foundation  
**Classification:** INTERNAL  
**Owner:** Engineering Platform Team

---

## Why This Document Exists

Every future capability — new AI agent, new MCP server, new policy rule, new observability feed, new UI channel — will enter the platform through a plugin registration. This document defines the contract that all plugins must satisfy. Once this contract is stable, the core platform never needs to change to support new capabilities.

This is the most important design document in the platform. Get it wrong and you spend 18 months untangling integration spaghetti. Get it right and every new capability is a 2-day integration.

---

## 1. Plugin Identity Schema

Every plugin, regardless of type or layer, must declare a standard identity block. This is the minimum registration payload.

```json
{
  "pluginId": "string — globally unique, kebab-case, e.g. mcp-github-copilot",
  "displayName": "string — human-readable, e.g. GitHub Copilot Agent",
  "version": "string — semver, e.g. 1.2.0",
  "layer": "interaction | governance | execution | integration",
  "type": "string — see type registry per layer below",
  "vendor": "string — internal | github | anthropic | custom",
  "owningTeam": "string — team name or cost center",
  "registeredAt": "ISO8601 timestamp",
  "status": "active | inactive | deprecated | experimental",
  "capabilities": ["string array — declared capability tokens"],
  "trustable": "boolean — whether ARIA should maintain a trust profile for this plugin",
  "costModel": {
    "unit": "token | request | minute | none",
    "rate": "number — cost per unit in USD",
    "budget": "number | null — monthly cap in USD, null = unlimited"
  },
  "healthCheck": {
    "endpoint": "string — URL or null for passive-only plugins",
    "intervalSeconds": "integer — how often to poll",
    "timeoutSeconds": "integer"
  },
  "metadata": {
    "description": "string — one paragraph max",
    "documentationUrl": "string | null",
    "tags": ["string array — for search and filtering"]
  }
}
```

### Validation Rules

- `pluginId` must be globally unique across all layers. Collision = rejected registration.
- `version` must be valid semver. Registering the same `pluginId` with a higher version creates a new version entry; it does not overwrite the previous version.
- `layer` must exactly match one of the four values. No cross-layer plugins.
- `trustable: true` requires `layer: "execution"` and `type: "agent"`. All other combinations are rejected.
- `costModel.rate` must be ≥ 0. If the plugin has no cost, set `unit: "none"` and `rate: 0`.

---

## 2. Layer-Specific Type Registry

Each layer has a fixed set of allowed plugin types. New types require a platform team review before they can be registered.

### 2.1 Interaction Layer Types

| Type | Purpose | Example |
|------|---------|---------|
| `ui` | Web dashboard or embedded UI component | ARIA Dashboard, ACES Workflow Builder |
| `api` | REST, GraphQL, or gRPC endpoint | Platform REST API v1 |
| `cli` | Command-line interface | `aria-cli`, `aces-cli` |
| `voice` | Voice/speech interface | Alexa skill, Teams voice bot |
| `webhook` | Inbound webhook receiver | GitHub PR webhook |
| `notification` | Outbound notification channel | Slack bot, Teams bot |

### 2.2 Governance Layer Types (ARIA)

| Type | Purpose | Example |
|------|---------|---------|
| `policy` | Risk rules and domain constraints | Auth service policy, PCI compliance rules |
| `feedback` | Post-deploy outcome sources | PagerDuty incident feed, Splunk alert feed |
| `cost-meter` | Cost tracking integrations | Token cost meter, pipeline cost tracker |
| `compliance` | Regulatory compliance modules | SOX audit module, DORA metrics |
| `explainer` | Custom explanation renderers | Plain-English explainer, Compliance report formatter |

### 2.3 Execution Layer Types (ACES)

| Type | Purpose | Example |
|------|---------|---------|
| `agent` | AI agent that generates or modifies artifacts | GitHub Copilot, Claude Dev Agent |
| `mcp-server` | MCP protocol server providing tools | GitHub MCP, Google Drive MCP |
| `tool` | Single-purpose tool invocation | Code formatter, Test runner, Security scanner wrapper |
| `workflow` | Multi-step workflow template | PR-to-deploy workflow, Code review workflow |
| `skill` | Reusable capability module | Java refactoring skill, SQL generation skill |

### 2.4 Integration Layer Types

| Type | Purpose | Example |
|------|---------|---------|
| `ci-cd` | CI/CD pipeline connector | GitHub Actions, Jenkins, ArgoCD |
| `scanner` | Security/quality scanner | Snyk, SonarQube, Raven |
| `observability` | Monitoring and alerting platforms | Datadog, Splunk, PagerDuty |
| `ticketing` | Issue and work tracking systems | JIRA, ServiceNow |
| `vcs` | Version control systems | GitHub, Bitbucket |
| `messaging` | Team messaging platforms | Slack, Microsoft Teams |

---

## 3. Capability Token Registry

Plugins declare capabilities using standardized tokens. ARIA uses these tokens to route decisions and apply domain-specific risk rules. New tokens require platform team approval.

### Agent Capability Tokens

```
code-generation          — generates new code
code-modification        — modifies existing code
code-review              — reviews and annotates code
test-generation          — generates test cases
documentation-generation — generates documentation
config-modification      — modifies configuration files
infrastructure-change    — modifies infrastructure definitions
pr-creation              — creates pull requests
pr-review                — reviews and approves pull requests
deployment-trigger       — triggers deployments
```

### Tool Capability Tokens

```
static-analysis          — static code analysis
vulnerability-scan       — security vulnerability detection
dependency-check         — dependency version analysis
secret-detection         — credential and secret scanning
data-retrieval           — retrieves data from external sources
file-manipulation        — creates, modifies, or deletes files
api-call                 — makes external API calls
database-query           — queries databases
```

### Integration Capability Tokens

```
pipeline-gate            — can block or allow pipeline progression
incident-source          — produces incident events consumed by ARIA
metric-source            — produces metrics consumed by ARIA
event-source             — produces generic events consumed by ARIA
notification-sink        — receives and delivers notifications
audit-sink               — receives and stores audit events
```

---

## 4. Plugin Lifecycle

```
DRAFT → REGISTERED → ACTIVE → INACTIVE → DEPRECATED → REMOVED
                         ↓
                    EXPERIMENTAL (bypass trust scoring, higher scrutiny)
```

### State Definitions

**DRAFT** — Plugin spec written but not yet submitted for registration. Exists only in version control.

**REGISTERED** — Submitted to plugin registry. Validated against schema. Not yet available for use. Pending health check and team approval.

**ACTIVE** — Available for use. ARIA applies full governance. Trust scoring active (if `trustable: true`).

**INACTIVE** — Temporarily disabled. No new invocations routed to this plugin. Existing in-flight invocations complete. Useful for maintenance windows.

**EXPERIMENTAL** — Active but flagged. Trust scoring applies heightened scrutiny. Maximum decision outcome is `REQUIRES_APPROVAL` regardless of computed risk score. Use for new agents in their first 10 PRs.

**DEPRECATED** — Marked for removal. Still functional but ARIA displays deprecation warnings in decisions. Owning team has 30 days to migrate users.

**REMOVED** — Deregistered. Historical decision records retain the plugin reference but no new invocations are possible.

### Trust Score Initialization

When an agent plugin (`trustable: true`) first registers:
- Initial trust score: **0.30** (EXPERIMENTAL band)
- Status set to: **EXPERIMENTAL**
- Minimum decision outcome: **REQUIRES_APPROVAL**
- Promotion to ACTIVE: after 10 clean deployments with zero incidents
- Trust score at promotion: **0.55** (LOW-MEDIUM band)

---

## 5. Plugin Interface Contracts by Layer

Each layer defines a standard interface that plugins must implement. This is the technical contract — the set of methods and events a plugin must support.

### 5.1 Execution Layer — Agent Plugin Interface

```typescript
interface AgentPlugin {
  // Required: Plugin identity
  getManifest(): PluginManifest;
  
  // Required: Health check
  ping(): Promise<{ status: 'healthy' | 'degraded' | 'unhealthy'; latencyMs: number }>;
  
  // Required: Execute a task
  execute(request: AgentRequest): Promise<AgentResponse>;
  
  // Required: Report execution metadata back to ARIA
  getExecutionMetadata(executionId: string): Promise<ExecutionMetadata>;
  
  // Optional: Cancel in-flight execution
  cancel?(executionId: string): Promise<void>;
  
  // Optional: Estimate cost before execution
  estimateCost?(request: AgentRequest): Promise<CostEstimate>;
}

interface AgentRequest {
  executionId: string;         // Platform-generated UUID
  taskType: string;            // e.g. "code-generation", "pr-review"
  context: {
    repoName: string;
    branch: string;
    filesInScope: string[];
    prId?: string;
    instructions: string;
  };
  constraints: {
    maxTokens?: number;
    timeoutSeconds: number;
    environment: 'dev' | 'staging' | 'prod';
  };
  ariaContext: {               // ARIA injects its decision context
    trustScore: number;
    priorDecision?: string;
    activeConstraints: string[];
  };
}

interface AgentResponse {
  executionId: string;
  status: 'completed' | 'failed' | 'cancelled' | 'timeout';
  artifacts: Artifact[];       // Files created or modified
  tokenCount: number;
  durationMs: number;
  agentReasoning?: string;     // Why the agent made specific choices (feeds Decision Archaeology)
  confidence?: number;         // Agent's self-reported confidence [0.0–1.0]
}
```

### 5.2 Execution Layer — MCP Server Plugin Interface

```typescript
interface McpServerPlugin {
  getManifest(): PluginManifest;
  ping(): Promise<HealthStatus>;
  
  // MCP protocol: list available tools
  listTools(): Promise<McpTool[]>;
  
  // MCP protocol: invoke a tool
  invokeTool(toolName: string, params: Record<string, unknown>): Promise<McpToolResult>;
  
  // ARIA extension: report tool invocation to governance
  reportInvocation(invocation: ToolInvocationRecord): Promise<void>;
}
```

### 5.3 Governance Layer — Policy Plugin Interface

```typescript
interface PolicyPlugin {
  getManifest(): PluginManifest;
  ping(): Promise<HealthStatus>;
  
  // Evaluate whether a change violates this policy
  evaluate(context: PolicyEvaluationContext): Promise<PolicyVerdict>;
  
  // List the rules this policy enforces
  getRules(): Promise<PolicyRule[]>;
}

interface PolicyEvaluationContext {
  agentId: string;
  filesChanged: string[];
  servicesInvolved: string[];
  environment: string;
  toolResults: Record<string, string>;
  agentTrustScore: number;
}

interface PolicyVerdict {
  passed: boolean;
  severity: 'info' | 'warning' | 'blocking';
  violatedRules: string[];
  reasoning: string;
}
```

### 5.4 Governance Layer — Feedback Plugin Interface

```typescript
interface FeedbackPlugin {
  getManifest(): PluginManifest;
  ping(): Promise<HealthStatus>;
  
  // Subscribe to events from this source
  subscribe(filter: FeedbackFilter): Promise<{ subscriptionId: string }>;
  
  // Unsubscribe
  unsubscribe(subscriptionId: string): Promise<void>;
  
  // Pull events (for polling-based sources)
  pullEvents?(since: string): Promise<FeedbackEvent[]>;
}

interface FeedbackEvent {
  eventId: string;
  timestamp: string;
  type: 'incident' | 'rollback' | 'slo-breach' | 'clean-deploy' | 'hotfix';
  severity: 'critical' | 'high' | 'medium' | 'low' | 'none';
  affectedServices: string[];
  linkedPrIds: string[];         // Correlated PRs
  correlationConfidence: number; // [0.0–1.0] how confident the link is
  detail: string;
}
```

### 5.5 Integration Layer — Scanner Plugin Interface

```typescript
interface ScannerPlugin {
  getManifest(): PluginManifest;
  ping(): Promise<HealthStatus>;
  
  // Trigger a scan and return results
  scan(target: ScanTarget): Promise<ScanResult>;
  
  // Receive webhook push results (for scanners that push results)
  receivePush?(payload: unknown): Promise<ScanResult>;
}

interface ScanResult {
  scannerId: string;
  timestamp: string;
  status: 'pass' | 'fail' | 'low' | 'medium' | 'high' | 'critical';
  findings: Finding[];
  rawReport?: string;            // Original scanner output
}
```

---

## 6. Plugin Registration API

### Register a Plugin

```
POST /api/v1/platform/plugins
Authorization: Bearer {service-token}
Content-Type: application/json

Body: Plugin Identity Schema (Section 1)

Response 201:
{
  "pluginId": "mcp-github-copilot",
  "registrationId": "REG-2025-001234",
  "status": "REGISTERED",
  "nextStep": "Health check will run within 60 seconds. Status will update to ACTIVE on success.",
  "ariaTrustInitialized": true,
  "initialTrustScore": 0.30
}

Response 409: Plugin ID already registered
Response 422: Schema validation failed (details in body)
```

### Query Plugin Registry

```
GET  /api/v1/platform/plugins                    → All plugins (paginated)
GET  /api/v1/platform/plugins/{pluginId}         → Single plugin detail
GET  /api/v1/platform/plugins?layer=execution    → Filter by layer
GET  /api/v1/platform/plugins?type=agent         → Filter by type
GET  /api/v1/platform/plugins?status=active      → Filter by status
```

### Update Plugin Status

```
PATCH /api/v1/platform/plugins/{pluginId}
Body: { "status": "inactive" }

Allowed transitions:
  REGISTERED → ACTIVE (system, post health check)
  ACTIVE → INACTIVE (team lead or platform admin)
  ACTIVE → EXPERIMENTAL (platform admin)
  EXPERIMENTAL → ACTIVE (system, post 10 clean deploys)
  ACTIVE → DEPRECATED (platform admin, requires migration plan)
  INACTIVE → ACTIVE (team lead or platform admin)
  DEPRECATED → REMOVED (platform admin, after 30-day window)
```

---

## 7. Plugin Discovery and Routing

ARIA discovers all active plugins automatically on startup and re-discovers every 60 seconds. No manual configuration required. The routing logic:

```
Incoming PR → ARIA Decision Engine
  ↓
  1. Load agent trust profile (Agent DNA Registry)
  2. Query active policy plugins (Governance Layer) → collect verdicts
  3. Query integration plugins for tool results (Integration Layer)
  4. Apply risk scoring model with all signals
  5. Produce decision + archaeology
  6. Route to execution plugins (Execution Layer) if ALLOW/ALLOW_WITH_WARNING
  7. Publish decision event → feedback plugins subscribe and report outcomes
```

When ARIA encounters an agent it has never seen:
1. Auto-provision trust profile with score 0.30
2. Set status to EXPERIMENTAL
3. Log: "Unknown agent encountered — auto-provisioned with low trust"
4. Apply maximum scrutiny until 10 clean deployments completed

---

## 8. Versioning and Backwards Compatibility

### Plugin Versioning

Plugins use semver (`MAJOR.MINOR.PATCH`):
- **PATCH** — bug fixes, no interface change. Auto-approved.
- **MINOR** — new optional capabilities added. Backwards compatible. Requires registry update.
- **MAJOR** — breaking interface change. Requires platform team review, migration plan, and 30-day deprecation of previous major version.

### Platform Interface Versioning

The platform plugin interface itself is versioned. Current version: `v1`. When `v2` is introduced, `v1` plugins continue to work for 6 months. After that, `v1` plugins are deprecated and must upgrade.

Plugins declare interface compatibility:

```json
{
  "interfaceVersion": "v1",
  "minPlatformVersion": "1.0.0"
}
```

---

## 9. Security Requirements for Plugins

All plugins must satisfy these security requirements before ACTIVE status:

**Authentication** — Plugins authenticate to the platform using short-lived JWT tokens (24-hour expiry). No long-lived credentials.

**Transport** — All plugin communication over TLS 1.3 minimum. No exceptions.

**Least privilege** — Plugins declare required scopes at registration. The platform grants only declared scopes. Scope escalation requires re-registration and platform team approval.

**Audit logging** — Every plugin invocation is logged with: timestamp, pluginId, callerIdentity, inputHash, outputHash, durationMs, statusCode. Logs retained 7 years.

**Secret handling** — Plugins must not log secrets, credentials, or PII. Violation triggers immediate INACTIVE status pending review.

**Sandboxing** — Execution layer plugins (agents, MCP servers) run in isolated containers. They cannot reach other plugins directly — all cross-plugin communication goes through the platform bus.

---

## 10. Sample Plugin Registrations

### Registering GitHub Copilot as an Agent Plugin

```json
{
  "pluginId": "agent-github-copilot-v1",
  "displayName": "GitHub Copilot Agent",
  "version": "1.0.0",
  "layer": "execution",
  "type": "agent",
  "vendor": "github",
  "owningTeam": "platform-engineering",
  "status": "experimental",
  "capabilities": [
    "code-generation",
    "code-modification",
    "pr-creation"
  ],
  "trustable": true,
  "costModel": {
    "unit": "token",
    "rate": 0.00002,
    "budget": 500.00
  },
  "healthCheck": {
    "endpoint": "https://internal-copilot-gateway/health",
    "intervalSeconds": 60,
    "timeoutSeconds": 5
  },
  "metadata": {
    "description": "GitHub Copilot enterprise agent. Generates and modifies code based on instructions.",
    "documentationUrl": "https://internal-wiki/copilot-setup",
    "tags": ["code-gen", "copilot", "github"]
  }
}
```

### Registering PagerDuty as a Feedback Plugin

```json
{
  "pluginId": "feedback-pagerduty",
  "displayName": "PagerDuty Incident Feed",
  "version": "1.0.0",
  "layer": "governance",
  "type": "feedback",
  "vendor": "pagerduty",
  "owningTeam": "platform-engineering",
  "status": "active",
  "capabilities": ["incident-source"],
  "trustable": false,
  "costModel": { "unit": "none", "rate": 0 },
  "healthCheck": {
    "endpoint": "https://api.pagerduty.com/ping",
    "intervalSeconds": 120,
    "timeoutSeconds": 10
  },
  "metadata": {
    "description": "Feeds production incident events from PagerDuty into ARIA trust score updates.",
    "tags": ["incidents", "observability", "feedback"]
  }
}
```

### Registering a Custom MCP Server

```json
{
  "pluginId": "mcp-internal-jira",
  "displayName": "JPMC Internal JIRA MCP Server",
  "version": "2.1.0",
  "layer": "execution",
  "type": "mcp-server",
  "vendor": "internal",
  "owningTeam": "developer-tools",
  "status": "active",
  "capabilities": ["ticketing", "api-call"],
  "trustable": false,
  "costModel": { "unit": "request", "rate": 0.0001 },
  "healthCheck": {
    "endpoint": "https://mcp-jira.internal/health",
    "intervalSeconds": 60,
    "timeoutSeconds": 5
  },
  "metadata": {
    "description": "MCP server exposing JIRA capabilities to AI agents — create tickets, update status, link PRs.",
    "tags": ["mcp", "jira", "ticketing"]
  }
}
```

---

## 11. Plugin Contract Checklist

Use this before submitting any plugin for registration:

**Identity**
- [ ] `pluginId` is globally unique, kebab-case, includes layer hint
- [ ] `version` is valid semver
- [ ] `layer` and `type` combination is in the type registry (Section 2)
- [ ] `capabilities` only contains tokens from the registry (Section 3)
- [ ] `trustable` is `true` only for execution/agent plugins

**Cost Model**
- [ ] `costModel.unit` is one of: token, request, minute, none
- [ ] `costModel.rate` is set and ≥ 0
- [ ] Monthly `budget` cap is set if the plugin has material cost

**Interface Implementation**
- [ ] Plugin implements all required methods for its type (Section 5)
- [ ] Health check endpoint responds within `timeoutSeconds`
- [ ] `interfaceVersion: "v1"` declared

**Security**
- [ ] Authentication using platform JWT (not long-lived credentials)
- [ ] TLS 1.3 on all endpoints
- [ ] Required scopes declared (minimum necessary)
- [ ] Audit logging implemented

**ARIA Integration (for agent plugins)**
- [ ] `agentReasoning` field populated in `AgentResponse`
- [ ] `ariaContext` consumed and respected in execution
- [ ] Prepared for EXPERIMENTAL status on first registration

---

*This document is the authoritative plugin contract specification. All plugins must satisfy it to receive ACTIVE status. The platform team reviews this document quarterly and publishes version updates with 60-day notice.*
