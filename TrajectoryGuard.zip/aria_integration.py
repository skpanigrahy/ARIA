"""
aria_integration.py

Wires TrajectoryGuard into ARIA's TrustScore as a new, runtime dimension:
TRAJECTORY_INTEGRITY.

ARIA's TrustScore today is a weighted composite of four dimensions,
computed largely from an agent's inputs, outputs, and policy adherence:

    behavioral, structural, integrity, budget_adherence

All four are evaluated *after* an agent run completes (or at coarse
checkpoints) -- they answer "was this a trustworthy result?" What none
of them answer is "did the agent's reasoning stay coherent *while it was
running*?" That's the gap TRAJECTORY_INTEGRITY closes: it scores the
execution trajectory step-by-step, in real time, so a bad turn can be
caught and rolled back before it becomes a bad result.

This file is a minimal, runnable sketch of that integration -- not the
production ARIA codebase -- to make the architecture concrete.
"""

from __future__ import annotations
from dataclasses import dataclass

from trajectory_guard import TrajectoryGuard, Trajectory
from synthetic_data import TOOL_VOCAB, ACTION_VOCAB


@dataclass
class TrustScoreDimensions:
    behavioral: float
    structural: float
    integrity: float
    budget_adherence: float
    trajectory_integrity: float  # new

    # same weighting philosophy as ARIA's existing composite: each
    # dimension contributes, but a hard trajectory anomaly should be
    # able to veto the score outright rather than being averaged away.
    WEIGHTS = {
        "behavioral": 0.25,
        "structural": 0.2,
        "integrity": 0.2,
        "budget_adherence": 0.15,
        "trajectory_integrity": 0.20,
    }

    def composite(self) -> float:
        return sum(getattr(self, k) * w for k, w in self.WEIGHTS.items())


class TrajectoryIntegrityScorer:
    """The ARIA-facing wrapper around TrajectoryGuard."""

    def __init__(self, guard: TrajectoryGuard):
        self.guard = guard

    def score(self, traj: Trajectory) -> dict:
        result = self.guard.score(traj, TOOL_VOCAB, ACTION_VOCAB)
        # map hybrid z-score onto ARIA's 0-100 dimension scale: a clean
        # trajectory (max z near baseline) scores near 100; anything past
        # the flagging threshold degrades sharply rather than linearly,
        # since a localized anomaly is a qualitatively different risk
        # than generic noise.
        peak = result["trajectory_score"]
        if result["verdict"] == "NORMAL":
            score_0_100 = max(70.0, 100.0 - peak * 5)
        else:
            score_0_100 = max(0.0, 40.0 - (peak - 3.0) * 8)
        return {
            "trajectory_integrity_score": round(score_0_100, 1),
            "verdict": result["verdict"],
            "localized_step": result["localized_step"],
            "flagged_steps": result["flagged_steps"],
            "raw_result": result,
        }


def rollback_and_retry(traj: Trajectory, integrity_result: dict) -> str:
    """
    Given a flagged trajectory, decide the rollback point. This is the
    payoff of *localization* over plain detection: instead of discarding
    the whole run, ARIA can replay from the last known-good step.
    """
    if integrity_result["verdict"] == "NORMAL":
        return "no action -- trajectory within trust bounds"

    step_idx = integrity_result["localized_step"]
    good_prefix = [s.raw_note for s in traj.steps[:step_idx]]
    return (
        f"ROLLBACK triggered at step {step_idx} "
        f"('{traj.steps[step_idx].raw_note}'). "
        f"Replaying from last verified state after: {good_prefix}. "
        f"Agent re-plans step {step_idx} onward under tightened policy "
        f"(e.g. require explicit eligibility-check tool call before any "
        f"payment_api.write)."
    )


if __name__ == "__main__":
    import numpy as np
    from synthetic_data import build_fit_corpus, anomalous_refund_trajectory

    rng = np.random.default_rng(99)
    fit_corpus = build_fit_corpus(n_refund=60, n_reset=60, seed=1)
    input_dim = fit_corpus[0].steps[0].to_vector(TOOL_VOCAB, ACTION_VOCAB).shape[0]

    guard = TrajectoryGuard(input_dim=input_dim, reservoir_dim=64, ridge_lambda=50.0)
    guard.fit(fit_corpus, TOOL_VOCAB, ACTION_VOCAB)
    scorer = TrajectoryIntegrityScorer(guard)

    bad_traj = anomalous_refund_trajectory(rng, "skip_verification")
    integrity_result = scorer.score(bad_traj)

    trust = TrustScoreDimensions(
        behavioral=88.0,      # would normally come from ARIA's existing evaluators
        structural=91.0,
        integrity=85.0,
        budget_adherence=95.0,
        trajectory_integrity=integrity_result["trajectory_integrity_score"],
    )

    print("TRAJECTORY_INTEGRITY dimension:", integrity_result["trajectory_integrity_score"])
    print("Verdict:", integrity_result["verdict"], "| Localized step:", integrity_result["localized_step"])
    print("Composite TrustScore (5 dimensions):", round(trust.composite(), 1))
    print()
    print(rollback_and_retry(bad_traj, integrity_result))
