"""
trajectory_guard.py

A lightweight, sequence-aware trajectory anomaly detector for LLM agents,
inspired by:
  - "Trajectory Guard" (Advani, arXiv:2601.00516) — Siamese Recurrent
    Autoencoder, hybrid contrastive-reconstruction loss.
  - "TrajAD: Trajectory Anomaly Detection for Trustworthy LLM Agents"
    (Liu et al., arXiv:2602.06443) — runtime process supervision with
    precise error localization for rollback-and-retry.

This is a from-scratch, dependency-light (numpy only) re-implementation
of the *architecture pattern* those papers describe, not a reproduction
of their trained models or reported numbers. Two design swaps were made
deliberately to keep this runnable anywhere in milliseconds with zero
training infrastructure:

  1. The recurrent encoder is a fixed random-weight reservoir (an Echo
     State Network) rather than a gradient-trained GRU. Reservoir
     computing is a well-established way to get sequence-aware,
     nonlinear temporal features without backprop — you only ever
     train a linear readout on top, which is a closed-form ridge
     regression. This is the difference between "train a small
     recurrent net for hours" and "solve one linear system in
     milliseconds," which matters if you want this to sit in an
     agent's hot path.
  2. "Training" = fitting that linear readout (reconstruction) and a
     set of per-task centroid vectors (contrastive/task-alignment) on
     a corpus of KNOWN-GOOD trajectories. No anomalies are needed at
     fit time — same as the papers' framing of anomaly detection as a
     one-class / process-supervision problem.

Two anomaly signals are combined, matching the "hybrid loss" idea:
  - Reconstruction error per step  -> catches "malformed step" /
    internally incoherent actions.
  - Task-centroid distance          -> catches "right-looking step,
    wrong task" / plan drift.
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# 1. Trajectory representation
# ---------------------------------------------------------------------------

@dataclass
class TrajectoryStep:
    """One step in an agent's execution trajectory."""
    tool: str
    action_type: str          # e.g. "read", "write", "call_api", "delete"
    risk_flag: float          # 0-1, pre-computed sensitivity of this action
    param_count: int
    latency_ms: float
    token_count: int
    raw_note: str = ""        # human-readable, not used numerically

    def to_vector(self, tool_vocab: dict, action_vocab: dict) -> np.ndarray:
        tool_onehot = np.zeros(len(tool_vocab))
        tool_onehot[tool_vocab[self.tool]] = 1.0
        action_onehot = np.zeros(len(action_vocab))
        action_onehot[action_vocab[self.action_type]] = 1.0
        numeric = np.array([
            self.risk_flag,
            self.param_count / 10.0,
            self.latency_ms / 1000.0,
            self.token_count / 500.0,
        ])
        return np.concatenate([tool_onehot, action_onehot, numeric])


@dataclass
class Trajectory:
    task_type: str
    steps: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# 2. Reservoir (fixed random recurrent encoder)
# ---------------------------------------------------------------------------

class ReservoirEncoder:
    """
    Echo State Network reservoir: a fixed, untrained recurrent layer that
    still produces temporally-aware, nonlinear features. Spectral radius
    is kept < 1 for stability (echo state property).
    """

    def __init__(self, input_dim: int, reservoir_dim: int = 64, seed: int = 7):
        rng = np.random.default_rng(seed)
        self.input_dim = input_dim
        self.reservoir_dim = reservoir_dim

        W_in = rng.normal(0, 0.5, size=(reservoir_dim, input_dim))
        W_res = rng.normal(0, 1.0, size=(reservoir_dim, reservoir_dim))
        # scale to a spectral radius of ~0.9 for stable dynamics
        eigvals = np.linalg.eigvals(W_res)
        W_res = W_res * (0.9 / np.max(np.abs(eigvals)))

        self.W_in = W_in
        self.W_res = W_res
        self.leak = 0.3  # leaky-integrator rate

    def encode(self, step_vectors: np.ndarray) -> np.ndarray:
        """step_vectors: (T, input_dim) -> hidden_states: (T, reservoir_dim)"""
        T = step_vectors.shape[0]
        h = np.zeros(self.reservoir_dim)
        hidden_states = np.zeros((T, self.reservoir_dim))
        for t in range(T):
            pre = self.W_in @ step_vectors[t] + self.W_res @ h
            h = (1 - self.leak) * h + self.leak * np.tanh(pre)
            hidden_states[t] = h
        return hidden_states


# ---------------------------------------------------------------------------
# 3. Hybrid reconstruction + contrastive scorer
# ---------------------------------------------------------------------------

class TrajectoryGuard:
    """
    Fits on known-good trajectories only. At inference time, scores each
    step of a new trajectory and returns both a trajectory-level anomaly
    score and per-step localization.
    """

    def __init__(self, input_dim: int, reservoir_dim: int = 64, ridge_lambda: float = 1e-2):
        self.encoder = ReservoirEncoder(input_dim, reservoir_dim)
        self.ridge_lambda = ridge_lambda
        self.W_readout: np.ndarray | None = None       # reconstruction decoder
        self.task_centroids: dict[str, np.ndarray] = {}
        self.recon_err_mu = 0.0
        self.recon_err_sigma = 1.0
        self.task_dist_mu = 0.0
        self.task_dist_sigma = 1.0

    def fit(self, trajectories: list, tool_vocab: dict, action_vocab: dict):
        all_hidden, all_targets, all_recon_errs, all_task_dists = [], [], [], []
        per_task_summaries: dict[str, list] = {}

        encoded_cache = []
        for traj in trajectories:
            vecs = np.stack([s.to_vector(tool_vocab, action_vocab) for s in traj.steps])
            hidden = self.encoder.encode(vecs)
            encoded_cache.append((traj, vecs, hidden))
            all_hidden.append(hidden)
            all_targets.append(vecs)
            per_task_summaries.setdefault(traj.task_type, []).append(hidden.mean(axis=0))

        H = np.vstack(all_hidden)
        X = np.vstack(all_targets)
        # closed-form ridge regression readout: H @ W^T ≈ X
        I = np.eye(H.shape[1])
        self.W_readout = np.linalg.solve(H.T @ H + self.ridge_lambda * I, H.T @ X).T

        for task, summaries in per_task_summaries.items():
            self.task_centroids[task] = np.mean(np.stack(summaries), axis=0)

        # calibrate normal-range statistics for both signals on the fit set
        for traj, vecs, hidden in encoded_cache:
            recon = hidden @ self.W_readout.T
            errs = np.linalg.norm(recon - vecs, axis=1)
            all_recon_errs.append(errs)
            centroid = self.task_centroids[traj.task_type]
            summary = hidden.mean(axis=0)
            dist = 1 - _cosine(summary, centroid)
            all_task_dists.append(dist)

        flat_errs = np.concatenate(all_recon_errs)
        self.recon_err_mu, self.recon_err_sigma = flat_errs.mean(), flat_errs.std() + 1e-6
        dists = np.array(all_task_dists)
        self.task_dist_mu, self.task_dist_sigma = dists.mean(), dists.std() + 1e-6
        return self

    def score(self, traj: Trajectory, tool_vocab: dict, action_vocab: dict) -> dict:
        vecs = np.stack([s.to_vector(tool_vocab, action_vocab) for s in traj.steps])
        hidden = self.encoder.encode(vecs)
        recon = hidden @ self.W_readout.T
        step_errs = np.linalg.norm(recon - vecs, axis=1)
        step_z = (step_errs - self.recon_err_mu) / self.recon_err_sigma

        centroid = self.task_centroids.get(traj.task_type)
        if centroid is None:
            task_z = np.zeros_like(step_z)
        else:
            summary = hidden.mean(axis=0)
            dist = 1 - _cosine(summary, centroid)
            task_z_scalar = (dist - self.task_dist_mu) / self.task_dist_sigma
            task_z = np.full_like(step_z, task_z_scalar)

        # Clip each signal before combining. Both z-scores are calibrated
        # on a fit corpus of normal trajectories, which cluster tightly --
        # without a ceiling, one saturated signal (most often task-distance,
        # since same-task trajectories are naturally very similar) can
        # swamp the other and destroy step-level localization.
        step_z = np.clip(step_z, -6, 6)
        task_z = np.clip(task_z, -6, 6)
        hybrid = 0.65 * step_z + 0.35 * task_z
        flagged = [i for i, s in enumerate(hybrid) if s > 3.0]  # ~3 sigma threshold
        return {
            "step_scores": hybrid.tolist(),
            "flagged_steps": flagged,
            # the single most likely fault origin -- this is what a
            # rollback-and-retry controller would act on directly
            "localized_step": int(np.argmax(hybrid)) if flagged else None,
            "trajectory_score": float(hybrid.max()),
            "verdict": "ANOMALOUS" if flagged else "NORMAL",
        }


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))
