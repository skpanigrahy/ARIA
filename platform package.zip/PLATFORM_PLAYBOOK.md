# The ARIA + ACES Platform Playbook
## From Innovation Week to Enterprise Platform

**Version:** 1.0  
**Audience:** Engineering leads, platform architects, product owners  
**Classification:** INTERNAL

---

## The One-Paragraph Summary

ARIA is the governance layer of a two-layer modular platform. It evaluates AI agent behavior using context and history, explains every decision with full transparency, and continuously learns from production outcomes. ACES is the execution layer — the runtime where agents perform work, tools are invoked, and workflows run. Together, they form a unified platform where execution and governance are separated but deeply integrated. New agents, tools, policies, and feedback sources are added as plugins without changing the core. The result is scalable, trustworthy AI adoption that enterprises can audit, explain, and extend indefinitely.

---

## Part 1: Mental Model

### The Central Insight

Every platform that scales has two fundamental concerns that must be separated:

**What gets done** — the work, the tasks, the execution. In our platform this is ACES.  
**Whether it should be done, and under what conditions** — the governance. In our platform this is ARIA.

When these two concerns live in the same system without clear separation, you get a system that is hard to scale, hard to debug, hard to explain, and hard to extend. Enterprises call this a black box. They avoid black boxes.

When they are separated but integrated — execution talks to governance, governance informs execution, outcomes feed back into governance — you get a platform. Platforms get adopted. Platforms outlast their initial use case.

### The Analogy

Think of a large bank's trading floor:

- **Traders** (ACES) execute trades, run strategies, use tools
- **Risk and compliance** (ARIA) evaluates every trade, maintains trader track records, blocks risky actions, learns from losses
- **Neither replaces the other.** Remove the traders and nothing gets done. Remove risk and compliance and the bank collapses.

Our platform is the same structure applied to AI-driven software development.

### What "Modular" Actually Means

Modular does not mean "we'll add features later." It means the core platform is designed around stable interfaces, and every new capability enters through a registered plugin. The core never changes to accommodate new capabilities — new capabilities adapt to the interface.

Concretely: when JPMC adopts a new AI agent in 2027, that agent registers against the plugin contract, gets an initial trust score of 0.30, moves through the EXPERIMENTAL phase, and earns ACTIVE status through clean deployments. Zero changes to ARIA's decision engine. Zero changes to ACES's execution runtime.

---

## Part 2: Platform Architecture

### The Four Layers

```
┌─────────────────────────────────────────────────────────┐
│                  INTERACTION LAYER                      │
│  How humans and systems talk to the platform            │
│  Plugins: UI, REST API, CLI, Voice, Webhooks            │
└─────────────────────────────────────────────────────────┘
                          ↕ decisions flow up
                          ↕ requests flow down
┌─────────────────────────────────────────────────────────┐
│             GOVERNANCE LAYER  ——  ARIA                  │
│  Trust · Risk · Explainability · Cost · Learning        │
│  Plugins: Policy rules, Feedback sources,               │
│           Cost meters, Compliance modules               │
└─────────────────────────────────────────────────────────┘
                          ↕ verdicts flow up
                          ↕ execution requests flow down
┌─────────────────────────────────────────────────────────┐
│             EXECUTION LAYER  ——  ACES                   │
│  Agents · Workflows · Tools · MCP Servers               │
│  Plugins: Copilot, Claude, MCP servers,                 │
│           Custom agents, Workflow templates             │
└─────────────────────────────────────────────────────────┘
                          ↕ events flow up
                          ↕ triggers flow down
┌─────────────────────────────────────────────────────────┐
│                 INTEGRATION LAYER                       │
│  CI/CD · Observability · Enterprise systems             │
│  Plugins: Snyk, Sonar, Raven, PagerDuty,               │
│           GitHub, JIRA, Datadog, Splunk                 │
└─────────────────────────────────────────────────────────┘
```

### Layer Responsibilities — Clear and Non-Negotiable

**Interaction Layer** — receives requests and delivers responses. It knows nothing about how decisions are made or how work gets done. It is a translation layer between the outside world and the platform.

**Governance Layer (ARIA)** — the control plane. It owns trust profiles, risk scoring, decision logic, audit records, cost accounting, and the feedback loop. It does not execute work. It decides whether work should happen and under what conditions.

**Execution Layer (ACES)** — the data plane. It runs agents, invokes tools, orchestrates workflows. It does not make governance decisions. It reports everything it does to the governance layer.

**Integration Layer** — the connector fabric. It translates between the platform's internal event model and the external systems the platform depends on. It knows the shape of Snyk's API. It knows how PagerDuty webhooks are structured. The rest of the platform does not.

### The Plugin Slot Model

Every capability in the platform lives in exactly one plugin slot. There are no special cases. There are no "core capabilities that aren't plugins." Even the built-in capabilities (the default policy engine, the default explainer) are registered as plugins internally — they just ship with the platform.

This matters because it means: if you can name a capability, you can add it, remove it, replace it, or upgrade it without touching anything else.

```
New AI agent?         → Register as execution/agent plugin
New MCP server?       → Register as execution/mcp-server plugin
New security policy?  → Register as governance/policy plugin
New incident source?  → Register as governance/feedback plugin
New scanner?          → Register as integration/scanner plugin
New UI?               → Register as interaction/ui plugin
New notification?     → Register as interaction/notification plugin
```

---

## Part 3: ARIA — The Governance Layer

### What ARIA Does

ARIA is the intelligence layer that makes AI-driven development trustworthy. It has three core capabilities:

**Agent DNA Profiling** keeps a persistent trust profile for every AI agent. Every PR, every deployment, every incident is attributed to the agent that caused it. Trust scores move continuously — improved by clean outcomes, reduced by incidents. A new agent starts with low trust and earns autonomy. A declining agent gets more scrutiny. Trust is earned, not assumed.

**Decision Archaeology** records every governance decision with full reasoning. Engineers get plain-English explanations of what the AI tried to do, why ARIA rated it as risky or safe, what specific signals drove the decision, and what should happen next. Every decision is auditable retroactively.

**Production Feedback Loop** closes the loop between deployment and learning. When a prod incident is attributed to an AI-generated change, that signal automatically updates the agent's trust score. When a change runs cleanly for 30 days, the agent is rewarded. The risk model improves with every deployment cycle.

### ARIA Decision Flow

```
1. PR payload received
   (agent ID, files changed, services, tool results, environment)
        ↓
2. Agent trust profile loaded
   (trust score, trend, history, last incident)
        ↓
3. Policy plugins consulted
   (each active policy plugin evaluates the change)
        ↓
4. Integration signals collected
   (Snyk, Sonar, Raven results normalized and weighted)
        ↓
5. Risk scoring computed
   (composite score from all signals)
        ↓
6. Decision produced
   (ALLOW / ALLOW_WITH_WARNING / REQUIRES_APPROVAL / BLOCK)
        ↓
7. Decision stored with full archaeology
   (structured event with plain-English explanation)
        ↓
8. Notifications dispatched
   (Slack for BLOCK/APPROVAL, JIRA ticket auto-created if needed)
        ↓
9. Feedback loop monitors outcome
   (incident correlation, trust score update)
```

### Trust Score Bands

| Score | Band | Meaning | Default Treatment |
|-------|------|---------|-------------------|
| 0.10–0.39 | Critical | New or consistently problematic agents | Maximum scrutiny, REQUIRES_APPROVAL minimum |
| 0.40–0.59 | Low | Declining trend or significant incident history | Elevated risk factor in scoring |
| 0.60–0.79 | Medium | Established agents with mixed track record | Standard risk factor |
| 0.80–0.94 | High | Proven agents with clean history | Reduced risk factor |
| 0.95–1.00 | Elite | Exceptional track record, deep domain expertise | Minimal risk addition |

### Decision Outcomes

| Decision | When Applied | Engineer Action Required |
|----------|-------------|------------------------|
| ALLOW | Low risk, high-trust agent, all signals green | None — change proceeds |
| ALLOW_WITH_WARNING | Low-medium risk, some caution warranted | Awareness only — change proceeds |
| REQUIRES_APPROVAL | Medium-high risk, human judgment needed | Engineering lead must approve |
| BLOCK | High risk, critical system, insufficient trust | Change cannot proceed until resolved |

### Cost Model in Governance

ARIA factors cost into decisions. Every plugin declares its cost model (cost per token, per request, per minute). ARIA tracks:

- **Per-decision cost** — what did this agent invocation cost?
- **Per-agent monthly cost** — rolling 30-day cost per agent
- **Rework cost** — cost of incidents and rollbacks attributed to AI-generated changes
- **Cost-efficiency score** — value delivered per dollar spent per agent

Cost signals feed into risk decisions:

```
High cost + low trust → RESTRICT (REQUIRES_APPROVAL even for low-risk changes)
High cost + high trust → MONITOR (cost alert without blocking)
Low cost + low trust  → SCRUTINIZE (trust-driven, cost not a factor)
Low cost + high trust → ALLOW (standard path)
```

---

## Part 4: ACES — The Execution Layer

### What ACES Does

ACES is the runtime where work happens. It provides three services:

**Agent Runtime** — manages the lifecycle of agent invocations. Receives an execution request from ARIA (post-decision), routes it to the correct agent plugin, monitors execution, collects output, and reports back.

**Workflow Engine** — orchestrates multi-step tasks. A workflow is a sequence of agent invocations, tool calls, and conditional branches. Each step is governed by ARIA before execution.

**Tool Invoker** — manages single-purpose tool invocations. Code formatters, test runners, data retrievers, MCP server calls. Each invocation is logged and attributed.

### ACES Execution Contract

Every execution in ACES follows this contract:

```
1. Receive execution request from ARIA (includes trust context)
2. Validate: agent plugin is ACTIVE
3. Validate: agent trust score permits this action
4. Execute: route to agent/tool/workflow plugin
5. Collect: execution metadata (tokens, duration, artifacts, agent reasoning)
6. Report: send execution record back to ARIA for audit log
7. Return: result to requestor
```

ACES never makes governance decisions. If an agent asks "should I do this?", ACES refers the question to ARIA. ACES only answers "how do I do this?"

### MCP Integration

MCP (Model Context Protocol) servers are first-class citizens in ACES. Any MCP server can be registered as an `execution/mcp-server` plugin. ACES routes tool calls through the MCP protocol. ARIA maintains trust scoring for MCP-invoked tools the same way it does for agent-generated code.

This means: when a Claude agent uses an MCP server to push to GitHub, ARIA sees both the agent invocation and the MCP tool call. Both are governed. Both contribute to the audit trail.

---

## Part 5: The Plugin System

### How to Add a New Capability (The Standard Path)

This is the answer to every future "can we add X?" question.

**Step 1: Identify the layer and type.**  
Where does X live? Consult the type registry in the Plugin Contract Spec.

**Step 2: Write the plugin manifest.**  
Fill in the Plugin Identity Schema. Declare capabilities using registered tokens.

**Step 3: Implement the interface.**  
Implement the layer-specific interface contract for your plugin type.

**Step 4: Register the plugin.**  
POST to `/api/v1/platform/plugins`. The platform validates the manifest, runs a health check, and sets status to ACTIVE.

**Step 5: ARIA auto-discovers.**  
Within 60 seconds, ARIA picks up the new plugin. If it's an agent, it initializes a trust profile. If it's a policy, it starts evaluating against it. If it's a feedback source, it starts subscribing to events.

That's it. No changes to ARIA's core. No changes to ACES's runtime. No restarts. No configuration files to update.

### Plugin Categories and What Goes Where

#### "We want to add a new AI agent" (e.g. a new internal coding agent)
→ Layer: Execution  
→ Type: `agent`  
→ ARIA trust profiling: automatic  
→ Starts at: EXPERIMENTAL with trust score 0.30  
→ Promoted to ACTIVE: after 10 clean deployments

#### "We want to add a new MCP server" (e.g. Confluence MCP, Salesforce MCP)
→ Layer: Execution  
→ Type: `mcp-server`  
→ ARIA trust profiling: none (MCP servers are tools, not agents)  
→ ARIA governance: invocations logged and attributed to the calling agent

#### "We want to add a new security policy" (e.g. no AI changes to PCI-scoped services without CISO approval)
→ Layer: Governance  
→ Type: `policy`  
→ ARIA trust profiling: not applicable  
→ Effect: policy is consulted on every ARIA decision for matching changes

#### "We want to connect a new observability platform" (e.g. New Relic)
→ Layer: Governance  
→ Type: `feedback`  
→ Effect: New Relic incident events feed into ARIA trust score updates

#### "We want to add a new scanner" (e.g. Checkmarx)
→ Layer: Integration  
→ Type: `scanner`  
→ Effect: Checkmarx results normalized and added to ARIA signal aggregation

#### "We want to add a new notification channel" (e.g. Teams, Email)
→ Layer: Interaction  
→ Type: `notification`  
→ Effect: ARIA decisions routed to this channel for BLOCK and REQUIRES_APPROVAL events

#### "We want to add cost tracking for a specific agent"
→ No new plugin needed  
→ Update the existing agent plugin's `costModel` field  
→ ARIA picks up the change on next discovery cycle

---

## Part 6: Phase-by-Phase Build Plan

### Phase 1 — Foundation (Innovation Week → Q1)

**Goal:** Prove the governance layer works end to end. Make ARIA real.

**Build:**
- Agent DNA Registry (identity store + trust score engine)
- Decision Engine (risk scoring + 4 decision outcomes)
- Decision Archaeology (event store + plain-English explainer)
- Plugin Registry (schema validation + discovery)
- Interaction Layer (REST API + Slack notification plugin)
- Integration Layer connectors: Snyk, Sonar, Raven (scanner plugins)
- Feedback connector: PagerDuty (feedback plugin)
- Demo UI (interaction/ui plugin)

**Simulate:**
- 2–3 pre-registered agent plugins (Copilot, Claude, 1 internal agent)
- 1 policy plugin (default platform policy)

**Pilot:**
- 2–3 volunteer engineering teams
- All their AI PRs go through ARIA
- Trust profiles start building from day 1

**Exit criteria:**  
Every AI PR in pilot teams has a full ARIA decision with archaeology. Zero unattributed AI-generated production incidents. Trust profiles showing differentiation between agents.

**What you do NOT build in Phase 1:**
- ACES execution runtime (simulated, not real)
- Workflow engine
- Voice interface
- Multi-agent orchestration
- Cost optimization features

### Phase 2 — Intelligence (Q2)

**Goal:** Close the feedback loop. Introduce real execution.

**Build:**
- Feedback loop automation (incident correlation → trust score update)
- ACES-lite: real agent execution routing (not simulated)
- Workflow engine v1 (single-agent, linear workflows only)
- MCP server plugin support
- Cost tracking module (governance layer)
- Agent trust leaderboard (engineering leads dashboard)
- JIRA integration (interaction/notification plugin)
- Trust score override workflow (dual approval)

**Connect:**
- ACES agent runtime connects to ARIA via plugin contract
- MCP servers begin registering (start with 2–3 internal ones)
- Cost data starts flowing into ARIA decisions

**Exit criteria:**  
Trust scores update automatically within 5 minutes of incident attribution. At least 3 agents show measurable trust score differentiation from production outcomes. ACES routing 100% of AI agent invocations through ARIA governance.

### Phase 3 — Platform (Q3–Q4)

**Goal:** Full platform. Enterprise-grade. Self-service.

**Build:**
- Self-service plugin onboarding portal (any team can register plugins)
- Policy editor (non-engineers can write and deploy policy plugins)
- Multi-agent workflow engine (agent-to-agent orchestration)
- Executive trust dashboard (CISO, CTO, VP Engineering)
- Compliance reporting exports (SOX, DORA metrics, custom)
- Risk model calibration (trained on JPMC incident corpus)
- Voice interface plugin
- Cross-BU agent registry

**Outcome:**  
Adding a new AI agent, MCP server, or policy rule requires zero engineering work on the platform team. Any team can self-serve. The platform grows without the core changing.

---

## Part 7: The Questions You Will Be Asked

### "What if ARIA gets it wrong and blocks a valid change?"

Every ARIA decision has a human override path. Override requires engineering lead approval and is logged with full context. The override is counted in ARIA's calibration data — if overrides cluster on specific scenarios, that's a signal to adjust the policy or risk model. ARIA's job is not to be perfect, it's to be transparent and improvable.

### "Does this slow down our pipelines?"

ARIA decision API SLA is under 3 seconds at p99. For a pipeline that takes 10–20 minutes, this is immaterial. For REQUIRES_APPROVAL decisions, the delay is human-gated anyway. For BLOCK decisions, the time saved by catching the issue pre-deploy is orders of magnitude larger than the latency added.

### "What happens if ARIA goes down?"

Failsafe mode. All AI-agent PRs default to REQUIRES_APPROVAL until ARIA recovers. Human-authored PRs are unaffected. ARIA targets 99.9% uptime with a circuit breaker that activates automatically if latency exceeds 5 seconds.

### "We use X agent/tool — can it plug in?"

If it can implement the plugin interface contract (Section 5 of the Plugin Contract Spec), yes. The interface is simple enough that most agents can be wrapped in a thin adapter. If the vendor exposes a REST API, we can write an adapter in a day.

### "Who owns this platform long-term?"

The Engineering Platform team. ARIA and ACES are internal platform capabilities, not a third-party product. This is intentional — the trust model depends on JPMC-specific incident history and internal agent behavior that no vendor can know. The platform is an internal competitive advantage.

### "How does this handle multi-agent workflows?"

Phase 2 introduces multi-agent workflow support. In a multi-agent workflow, ARIA applies the minimum trust score across all participating agents. If one agent in a 4-agent workflow has a trust score of 0.35, the entire workflow is treated at that trust level. This conservative approach prevents a trusted agent from being used as a conduit for a low-trust agent's risky actions.

---

## Part 8: The Platform Team's First 90 Days

### Week 1–2: Foundation
- Lock the plugin contract (do not change it after this point without a version bump)
- Stand up the plugin registry with schema validation
- Register the 3 built-in plugins: default policy, PagerDuty feedback, Slack notification
- Instrument ARIA's decision API with latency and error rate metrics

### Week 3–4: First Agents
- Register Copilot and Claude as EXPERIMENTAL agent plugins
- Stand up pilot with Team A
- Begin collecting trust profile data (no decisions yet — observe mode)

### Week 5–8: Go Live with Decisions
- Enable ARIA decisions for pilot teams
- Connect Snyk, Sonar, Raven as integration plugins
- First decision archaeology records appear in audit log
- Weekly calibration reviews: are decisions reasonable?

### Week 9–12: Widen the Pilot
- Add 2 more teams
- Enable PagerDuty feedback loop
- First trust score deltas from prod outcomes
- Publish first agent trust leaderboard to engineering leads

### Day 90 Review
- Trust profiles for all registered agents showing differentiation
- At least 1 high-profile BLOCK decision that prevented a potential incident
- At least 1 ALLOW decision that the team would have over-blocked manually
- Engineering satisfaction survey — is ARIA explaining itself clearly?

---

## Appendix A: Glossary

| Term | Definition |
|------|-----------|
| ARIA | Adaptive Risk Intelligence for AI Agents — the governance layer |
| ACES | Autonomous Capability Execution System — the execution layer |
| Plugin | A registered capability that conforms to the platform plugin contract |
| Plugin contract | The interface specification every plugin must satisfy |
| Trust score | A continuous value [0.10–1.00] representing an agent's earned trustworthiness |
| Agent DNA | The persistent behavioral profile of an AI agent |
| Decision Archaeology | The structured, explainable record of every ARIA governance decision |
| Prod feedback loop | The mechanism by which production outcomes update agent trust profiles |
| MCP | Model Context Protocol — the standard for AI agent tool integration |
| EXPERIMENTAL | Plugin status for new agents — heightened scrutiny, max REQUIRES_APPROVAL |
| Capability token | A standardized string declaring what a plugin can do |
| Trust band | A named range of trust scores (Critical / Low / Medium / High / Elite) |

## Appendix B: What NOT to Build

These are the things that will be suggested during Innovation Week or Phase 1. They are good ideas. They belong in Phase 2 or Phase 3. Do not build them now.

- Multi-agent workflow orchestration → Phase 3
- Voice interface → Phase 3  
- Cost optimization recommendations → Phase 2
- Self-service policy editor → Phase 3
- Cross-BU agent registry → Phase 3
- Risk model trained on incident corpus → Phase 3
- Executive compliance reports → Phase 3
- Agent-to-agent trust delegation → Phase 3
- Automated remediation suggestions → Phase 2

The discipline of saying "Phase 3" to everything that isn't on the Phase 1 list is what separates platforms that ship from platforms that get redesigned indefinitely.

---

*This playbook is a living document. It will be updated at the end of each phase with learnings, corrections, and the next phase detail. Version history maintained in the platform engineering wiki.*
