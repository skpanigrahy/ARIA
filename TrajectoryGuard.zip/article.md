# Your Agent's Output Looked Fine. Its Reasoning Wasn't.

### Why runtime trajectory verification is the missing layer in agent trust — and what it looks like to build one into ARIA

---

Every agent safety stack I've worked with — ARIA included, until recently — checks two things well: what went in, and what came out. Input filtering, output validation, policy checks on the final action. That's the entire surface area most trust layers watch.

Here's the problem: a five-step agent trajectory can go wrong at step two and still produce a final output that passes every downstream check. The refund gets issued. The email gets sent. Nothing about the *output* looks anomalous — because by the time you're looking at the output, the damage (skipping an eligibility check, taking an unplanned detour through a delete-account call) already happened three steps upstream, invisibly, in the part of the run nobody was watching.

That gap — between output-level safety and process-level safety — is exactly what a small cluster of early-2026 papers has started to formalize. I spent this week reading them, then spent a day building the piece that was missing from ARIA's TrustScore. This is the write-up of both.

## The research: watching the process, not just the outcome

Two papers converge on the same diagnosis from different angles.

**TrajAD** (Liu et al., arXiv:2602.06443) frames it directly: current safety measures are almost entirely static input/output filtering, but trustworthy agents need auditing of the *intermediate execution process* — not just detection of a bad run, but precise *localization* of where it went wrong, because localization is what makes rollback-and-retry possible instead of discarding the whole trajectory. The authors also found something worth sitting with: general-purpose LLMs, even prompted zero-shot to spot these anomalies, are bad at it. Being a capable model doesn't automatically make you a reliable process auditor — that's a distinct, learnable skill, and the paper argues it needs dedicated supervision to acquire.

**Trajectory Guard** (Advani, arXiv:2601.00516) tackles the same problem from the modeling side, and its architectural framing is the more useful one to build from. It identifies two failure modes existing anomaly-detection approaches miss: mean-pooling an agent's step embeddings dilutes exactly the anomalous step you're trying to find, while contrastive-only approaches ignore sequence structure entirely — they can tell you a trajectory looks unusual, but not whether the *steps in the wrong order* is the problem. Its answer is a hybrid: a sequence-aware model trained on both a contrastive objective (does this trajectory match the task it claims to be doing?) and a reconstruction objective (is each step internally coherent?) at once. The reported numbers are the kind that make a platform engineer sit up — F1 in the 0.88-0.94 range on balanced benchmarks, and inference at roughly 32ms, 17 to 27 times faster than using an LLM-as-judge for the same check. Fast enough to sit in an agent's hot path, not just in a nightly audit job.

Neither paper is about making agents smarter. Both are about making agents *auditable while they think* — which is a different, and I'd argue more urgent, problem.

## Why "more urgent" isn't hyperbole

There's a third paper worth naming here, not to implement but to frame the stakes: a survey published just last week, "Self-Improvements in Modern Agentic Systems" (arXiv:2607.13104), formalizes a trend that's been visible in production for a while — agents are increasingly allowed to modify their own scaffolding at runtime: their prompts, their memory, their tool routing, their control logic, sometimes even their own weights. The survey's whole contribution is giving that trend a shared vocabulary, splitting self-improvement into "slow" weight updates and "fast" scaffold updates.

Sit with what that means for a static, output-only safety net: it was designed to catch a fixed agent doing a fixed thing wrong. It was never designed to catch a *self-modifying* agent whose control logic this week isn't the control logic it shipped with. If the agent itself is a moving target, the only safety layer that keeps working is the one watching the process as it unfolds — not the one waiting for a final answer to compare against a policy. That's the future-perspective case for runtime trajectory verification: it's not a nice-to-have hardening measure, it's the one category of defense that doesn't quietly expire as agents get more autonomous.

## The build: a trajectory guard for ARIA

ARIA's TrustScore today is a weighted composite across four dimensions — behavioral, structural, integrity, budget adherence — all of which are fundamentally post-hoc: they score a completed run, or check policy adherence at coarse checkpoints. None of them ask "did the reasoning stay coherent *while* the agent was executing it." That's the dimension I built: **TRAJECTORY_INTEGRITY**.

I deliberately didn't try to reproduce Trajectory Guard's trained GRU line-for-line. For a first prototype I wanted something that trains in milliseconds with zero GPU infrastructure and is honest about being a simplified stand-in for the architecture pattern, not the paper's model. So I made two swaps:

**Reservoir instead of a trained recurrent net.** The encoder is an Echo State Network — a fixed, randomly-weighted recurrent layer with a spectral radius under 1 for stability. It's still genuinely sequence-aware (each step's hidden state is a nonlinear function of everything before it), but nothing in it is gradient-trained. You only ever fit a *linear* readout on top of it, which turns "train a small recurrent net" into "solve one linear system." This is old, unglamorous reservoir-computing theory doing new work at the edge of an agent framework.

**Closed-form ridge regression instead of a learned loss.** "Training" the reconstruction half means fitting one ridge regression on known-good trajectories — no anomalies required at fit time, which matches both papers' framing of this as a one-class problem. The contrastive half is even simpler: per-task centroid vectors (mean-pooled hidden states for each task type), with new trajectories scored by cosine distance to their task's centroid.

Two anomaly signals, matching the hybrid-loss idea directly:

```python
hybrid = 0.65 * step_z + 0.35 * task_z
```

`step_z` is reconstruction error at each step — it catches a step that's internally incoherent (wrong tool, wrong risk profile for that action type). `task_z` is the trajectory's distance from its task's normal centroid, broadcast across all steps — it catches "every individual step looks fine, but this trajectory as a whole has drifted off-task." One caveat that cost me a debugging session and is worth naming honestly: both z-scores need to be clipped before combining. Trajectories of the same task type cluster *very* tightly in a small synthetic corpus, which makes the task-distance signal's normal variance nearly zero — and an unclipped near-zero-variance signal will blow past 900-sigma on the first real deviation and swamp the step-level localization completely. Capping both signals at ±6 before the weighted sum was the fix.

## Does it actually work?

I fit the guard on 120 synthetic "known-good" trajectories across two task types (a refund flow and a password-reset flow), then evaluated it on held-out normal runs and on runs with a single corrupted step injected at a known position — same trajectory length, same surrounding steps, one step swapped for a plausible-looking failure (an eligibility check silently skipped; an unplanned account-deletion call slipped into a refund flow).

```
PHASE 1 — false positives on 60 held-out NORMAL trajectories
False positives: 0/60  (0.0%)
Mean inference latency: 0.09 ms/trajectory

PHASE 2 — detection + localization on injected-anomaly trajectories
Scenario: issue_refund without eligibility check
  Per-step anomaly scores (z): [2.18, 6.0, 5.15, 2.77, 2.74]
  Rollback target (peak): step 1  (expected fault at step 1) ✓

Scenario: unexpected account deletion mid-refund
  Per-step anomaly scores (z): [2.17, 1.49, 6.0, 3.18, 0.36]
  Rollback target (peak): step 2  (expected fault at step 2) ✓

Detection rate: 4/4 anomalous trajectories flagged
```

Zero false positives on normal runs, 4/4 detection, and — more interesting than the detection rate — the peak anomaly score landed on the *actual* corrupted step in every case, not just somewhere in its vicinity. Sub-millisecond inference, which isn't a fair comparison to the paper's already-fast 32ms (different scale, different task, synthetic data), but it does prove the core claim: this class of check is cheap enough to run on every step of every agent trajectory without anyone noticing the latency.

## Wiring it into TrustScore

```python
trust = TrustScoreDimensions(
    behavioral=88.0,
    structural=91.0,
    integrity=85.0,
    budget_adherence=95.0,
    trajectory_integrity=16.0,   # this run's actual score
)
# Composite TrustScore (5 dimensions): 74.7
```

That number is the whole argument in one line. Every existing ARIA dimension looked healthy on this run — 88, 91, 85, 95, the kind of profile that sails through review. Trajectory integrity alone caught what nothing else did, and pulled a composite score that would've cleared the bar down to 74.7. Then, because the anomaly is *localized* and not just detected, ARIA doesn't have to throw the whole run away:

```
ROLLBACK triggered at step 1 ('issue_refund_UNVERIFIED').
Replaying from last verified state after: ['lookup_order'].
Agent re-plans step 1 onward under tightened policy
(e.g. require explicit eligibility-check tool call before any payment_api.write).
```

Rollback-and-retry from the last verified step, not from scratch. That's the payoff of localization over plain anomaly detection — it turns "something's wrong, kill the run" into "something's wrong here, specifically, retry from just before it."

## Where I'd push next, and what this isn't

This is a working prototype, not a production claim. The corpus is synthetic and small; a reservoir encoder is a legitimate and fast sequence model but it's not going to match a properly trained GRU or transformer on subtler anomalies, especially ones that don't show up as a clean single-step corruption. Real agent trajectories are messier than two clean task templates. The next honest steps are: fit on real ARIA execution logs instead of synthetic ones, tune the clipping bounds against a real false-positive budget instead of an eyeballed threshold, and figure out whether trajectory_integrity should be able to *veto* the composite outright rather than just weighting into it — a 74.7 still passes a lot of review gates, and a caught rollback that still produces a "pretty good" composite score is a policy question, not just an engineering one.

But the direction feels right, and it's a direction that gets more necessary, not less, as the self-improving-agents survey's framing plays out in production: the more an agent's own scaffold is a moving target, the more the only thing worth trusting is a layer that watches it move.

---

*Code for this piece — `trajectory_guard.py`, `synthetic_data.py`, `aria_integration.py` — is a from-scratch, dependency-light re-implementation of the architecture pattern in Trajectory Guard (arXiv:2601.00516) and TrajAD (arXiv:2602.06443), not a reproduction of either paper's trained models or reported benchmark numbers.*
