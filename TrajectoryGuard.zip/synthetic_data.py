"""
synthetic_data.py

Generates synthetic agent execution trajectories for two task types,
to fit and evaluate TrajectoryGuard without needing real production logs.

Task types:
  - "refund_request": lookup_order -> verify_eligibility -> compute_refund
                       -> issue_refund -> notify_customer
  - "password_reset":  verify_identity -> check_recent_activity
                       -> generate_reset_token -> send_reset_email

Vocab is shared across both tasks so the encoder sees a consistent
feature space.
"""

import numpy as np
from trajectory_guard import TrajectoryStep, Trajectory

TOOLS = ["order_db", "auth_service", "payment_api", "email_service", "user_db"]
ACTIONS = ["read", "verify", "compute", "write", "notify", "delete"]

TOOL_VOCAB = {t: i for i, t in enumerate(TOOLS)}
ACTION_VOCAB = {a: i for i, a in enumerate(ACTIONS)}


def _step(tool, action, risk, params, latency, tokens, note=""):
    return TrajectoryStep(tool, action, risk, params, latency, tokens, note)


def normal_refund_trajectory(rng) -> Trajectory:
    jitter = lambda base, spread: base + rng.normal(0, spread)
    steps = [
        _step("order_db", "read", 0.1, 2, jitter(120, 15), jitter(80, 10), "lookup_order"),
        _step("order_db", "verify", 0.2, 3, jitter(150, 20), jitter(100, 10), "verify_eligibility"),
        _step("payment_api", "compute", 0.3, 2, jitter(90, 10), jitter(60, 8), "compute_refund"),
        _step("payment_api", "write", 0.6, 3, jitter(200, 25), jitter(120, 15), "issue_refund"),
        _step("email_service", "notify", 0.1, 1, jitter(80, 10), jitter(50, 5), "notify_customer"),
    ]
    return Trajectory(task_type="refund_request", steps=steps)


def normal_password_reset_trajectory(rng) -> Trajectory:
    jitter = lambda base, spread: base + rng.normal(0, spread)
    steps = [
        _step("auth_service", "verify", 0.2, 2, jitter(100, 12), jitter(70, 8), "verify_identity"),
        _step("user_db", "read", 0.1, 1, jitter(90, 10), jitter(50, 5), "check_recent_activity"),
        _step("auth_service", "write", 0.4, 2, jitter(110, 15), jitter(60, 8), "generate_reset_token"),
        _step("email_service", "notify", 0.1, 1, jitter(80, 10), jitter(50, 5), "send_reset_email"),
    ]
    return Trajectory(task_type="password_reset", steps=steps)


def anomalous_refund_trajectory(rng, kind="skip_verification") -> Trajectory:
    """
    Injects a realistic failure mode at a known step index, keeping the
    trajectory the same LENGTH as a normal one so the anomaly is a single
    corrupted step rather than a structurally different sequence. This is
    what makes localization meaningful: everything except the injected
    step matches the normal skeleton.
    """
    jitter = lambda base, spread: base + rng.normal(0, spread)
    if kind == "skip_verification":
        # step 1 (verify_eligibility) is replaced by a premature write to
        # payment_api -- the eligibility gate never actually ran.
        steps = [
            _step("order_db", "read", 0.1, 2, jitter(120, 15), jitter(80, 10), "lookup_order"),
            _step("payment_api", "write", 0.9, 3, jitter(190, 20), jitter(115, 12), "issue_refund_UNVERIFIED"),
            _step("payment_api", "compute", 0.3, 2, jitter(90, 10), jitter(60, 8), "compute_refund"),
            _step("payment_api", "write", 0.6, 3, jitter(200, 25), jitter(120, 15), "issue_refund"),
            _step("email_service", "notify", 0.1, 1, jitter(80, 10), jitter(50, 5), "notify_customer"),
        ]
    elif kind == "task_drift":
        # step 2 (compute_refund) is replaced by an out-of-scope account
        # deletion -- same position, same surrounding steps, wrong action.
        steps = [
            _step("order_db", "read", 0.1, 2, jitter(120, 15), jitter(80, 10), "lookup_order"),
            _step("order_db", "verify", 0.2, 3, jitter(150, 20), jitter(100, 10), "verify_eligibility"),
            _step("user_db", "delete", 0.95, 1, jitter(60, 10), jitter(40, 5), "DELETE_ACCOUNT_unexpected"),
            _step("payment_api", "write", 0.6, 3, jitter(200, 25), jitter(120, 15), "issue_refund"),
            _step("email_service", "notify", 0.1, 1, jitter(80, 10), jitter(50, 5), "notify_customer"),
        ]
    else:
        raise ValueError(kind)
    return Trajectory(task_type="refund_request", steps=steps)


def build_fit_corpus(n_refund=40, n_reset=40, seed=42):
    rng = np.random.default_rng(seed)
    corpus = [normal_refund_trajectory(rng) for _ in range(n_refund)]
    corpus += [normal_password_reset_trajectory(rng) for _ in range(n_reset)]
    return corpus
